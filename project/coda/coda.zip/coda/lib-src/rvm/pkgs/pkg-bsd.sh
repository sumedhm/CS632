#!/bin/sh

if [ $# != 2 ]
then
  echo "Usage $0 <version> [NetBSD|FreeBSD]"
  exit
fi

VERSION=$1
BSD=$2

function MakePortsTree () {
    ver=$1
    bsd=$2

    # make ports stuff
    mkdir devel
    MakeSubTree ${ver} ${bsd}

#    chown -R root.root devel
}

function MakeSubTree () {
    ver=$1
    bsd=$2

    mkdir devel/rvm
    MakeMakefile ${ver} devel/rvm/Makefile ${bsd}

    mkdir devel/rvm/files

    if [ x${bsd} = xNetBSD ]
    then
	cat > /tmp/mf << EOF
\$NetBSD\$

EOF
    else
	cp /dev/null /tmp/mf
    fi

    for dir in . .. ../.. ; do
      if [ -f ${dir}/rvm-${ver}.tar.gz ] ; then
	( cd ${dir} ; md5sum rvm-${ver}.tar.gz | awk '{printf("MD5 (%s) = %s\n",$2,$1)}' >> /tmp/mf )
	mv /tmp/mf devel/rvm/files/md5
	break;
      fi
    done
    rm -f /tmp/mf

    mkdir devel/rvm/pkg

    cat > devel/rvm/pkg/COMMENT << EOF
RVM persistent VM library
EOF
    cat > devel/rvm/pkg/DESCR << EOF
The RVM persistent VM library. The RVM library is used by the Coda distributed
filesystem.
EOF

    MakePLIST devel/rvm/pkg/PLIST ${bsd}
}

function MakeMakefile () {
  version=$1
  dest=$2
  if [ x$3 = xNetBSD ]
  then
    REMOVE=FreeBSD
    KEEP=NetBSD
  else
    REMOVE=NetBSD
    KEEP=FreeBSD
  fi

  cat > /tmp/mf << EOF
@NetBSD # \$NetBSD\$
@NetBSD #
@FreeBSD # New ports collection makefile for:	rvm
@FreeBSD # Version required:			1.17
@FreeBSD # Date created:				@DATE@
@FreeBSD # Whom:					@USER@
@FreeBSD # \$FreeBSD\$
@FreeBSD #

DISTNAME=	rvm-1.17
@NetBSD PKGNAME=	rvm-1.17
@FreeBSD PORTNAME=	rvm
@FreeBSD PORTVERSION=	1.17
CATEGORIES=	devel
MASTER_SITES=	ftp://ftp.coda.cs.cmu.edu/pub/rvm/src/
EXTRACT_SUFX=	.tar.gz

MAINTAINER=	coda@cs.cmu.edu
@NetBSD HOMEPAGE=	http://www.coda.cs.cmu.edu/
@FreeBSD LIB_DEPENDS=	lwp.2:\${PORTSDIR}/devel/lwp
@NetBSD DEPENDS=	lwp-2.4:../lwp

@NetBSD #ONLY_FOR_ARCHS=	arm32 i386 ns32k
@NetBSD 
@NetBSD LICENSE=	LGPL
@NetBSD 
ALL_TARGET=	all
INSTALL_TARGET=	install

GNU_CONFIGURE=	yes
USE_GMAKE=	yes
USE_LIBTOOL=	yes

@NetBSD .include "../../mk/bsd.pkg.mk"
@FreeBSD .include <bsd.port.mk>
EOF

    cat /tmp/mf | sed -e "s/1.17/${version}/" | \
		  sed -e "s/@DATE@/`date`/" | \
		  sed -e "s/@USER@/${USER}/" | \
		  sed -e "/^@${REMOVE} .*$/d" | \
		  sed -e "s/^@${KEEP} \(.*\)$/\1/" > ${dest}
    rm /tmp/mf
}

function MakePLIST () {
    dst=$1
    bsd=$2

    if [ x${bsd} = xNetBSD ]
    then
	cat > ${dst} << EOF
@comment \$NetBSD\$
lib/librvmlwp.so.3.4
lib/libseglwp.so.3.4
lib/librdslwp.so.3.4
EOF
    else
	cat > ${dst} << EOF
lib/librvmlwp.so
lib/librvmlwp.so.3
lib/libseglwp.so
lib/libseglwp.so.3
lib/librdslwp.so
lib/librdslwp.so.3
EOF
    fi

    cat >> ${dst} << EOF
sbin/rvmutl
sbin/rdsinit
lib/librvmlwp.a
lib/librvmlwp.la
lib/libseglwp.a
lib/libseglwp.la
lib/librdslwp.a
lib/librdslwp.la
lib/pkgconfig/rvmlwp.pc
include/rvm/rvm.h
include/rvm/rvm_statistics.h
include/rvm/rvm_segment.h
include/rvm/rds.h
EOF
}

MakePortsTree $VERSION $BSD
tar -czf pkg-rvm-$VERSION-$BSD.tgz devel
rm -rf devel

