
#ifdef __cplusplus
extern "C" {
#endif

#include <sys/types.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>


#ifdef __cplusplus
}
#endif

#define _PAD(n)	((((n)-1) | 3) + 1)

int update_PrintOpcode(int opcode, int subsysid) {
/*    Subsystem : update */

    printf("update:");

    switch (opcode) {
	case UpdateFetch_OP:
		printf("UpdateFetch_OP");
		break;
	case RPC2_NEWCONNECTION:
		printf("RPC2_NEWCONNECTION");
		break;
	default:
		printf("%d",opcode);
    }
}
