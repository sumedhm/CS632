
#ifdef __cplusplus
extern "C" {
#endif

#include <sys/types.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>


#ifdef __cplusplus
}
#endif

#define _PAD(n)	((((n)-1) | 3) + 1)

int mond_PrintOpcode(int opcode, int subsysid) {
/*    Subsystem : mond */

    printf("mond:");

    switch (opcode) {
	case MondEstablishConn_OP:
		printf("MondEstablishConn_OP");
		break;
	case VmonReportSession_OP:
		printf("VmonReportSession_OP");
		break;
	case VmonReportCommEvent_OP:
		printf("VmonReportCommEvent_OP");
		break;
	case VmonReportCallEvent_OP:
		printf("VmonReportCallEvent_OP");
		break;
	case VmonReportMCallEvent_OP:
		printf("VmonReportMCallEvent_OP");
		break;
	case VmonReportRVMStats_OP:
		printf("VmonReportRVMStats_OP");
		break;
	case VmonReportAdviceStats_OP:
		printf("VmonReportAdviceStats_OP");
		break;
	case VmonReportMiniCache_OP:
		printf("VmonReportMiniCache_OP");
		break;
	case VmonReportOverflow_OP:
		printf("VmonReportOverflow_OP");
		break;
	case SmonNoop_OP:
		printf("SmonNoop_OP");
		break;
	case SmonReportCallEvent_OP:
		printf("SmonReportCallEvent_OP");
		break;
	case SmonReportResEvent_OP:
		printf("SmonReportResEvent_OP");
		break;
	case SmonReportOverflow_OP:
		printf("SmonReportOverflow_OP");
		break;
	case SmonReportRVMResStats_OP:
		printf("SmonReportRVMResStats_OP");
		break;
	case VmonReportIotInfo_OP:
		printf("VmonReportIotInfo_OP");
		break;
	case VmonReportIotStats_OP:
		printf("VmonReportIotStats_OP");
		break;
	case VmonReportSubtreeStats_OP:
		printf("VmonReportSubtreeStats_OP");
		break;
	case VmonReportRepairStats_OP:
		printf("VmonReportRepairStats_OP");
		break;
	case VmonReportRwsStats_OP:
		printf("VmonReportRwsStats_OP");
		break;
	case VmonReportVCBStats_OP:
		printf("VmonReportVCBStats_OP");
		break;
	default:
		printf("%d",opcode);
    }
}
