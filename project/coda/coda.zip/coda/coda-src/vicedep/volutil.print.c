
#ifdef __cplusplus
extern "C" {
#endif

#include <sys/types.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>


#ifdef __cplusplus
}
#endif

#define _PAD(n)	((((n)-1) | 3) + 1)

int volUtil_PrintOpcode(int opcode, int subsysid) {
/*    Subsystem : volUtil */

    printf("volUtil:");

    switch (opcode) {
	case VolSalvage_OP:
		printf("VolSalvage_OP");
		break;
	case VolCreate_OP:
		printf("VolCreate_OP");
		break;
	case VolInfo_OP:
		printf("VolInfo_OP");
		break;
	case VolMakeVLDB_OP:
		printf("VolMakeVLDB_OP");
		break;
	case VolMakeVRDB_OP:
		printf("VolMakeVRDB_OP");
		break;
	case VolShowVnode_OP:
		printf("VolShowVnode_OP");
		break;
	case VolSetVV_OP:
		printf("VolSetVV_OP");
		break;
	case VolPurge_OP:
		printf("VolPurge_OP");
		break;
	case VolLookup_OP:
		printf("VolLookup_OP");
		break;
	case VolUpdateDB_OP:
		printf("VolUpdateDB_OP");
		break;
	case VolShutdown_OP:
		printf("VolShutdown_OP");
		break;
	case VolSwaplog_OP:
		printf("VolSwaplog_OP");
		break;
	case VolSetDebug_OP:
		printf("VolSetDebug_OP");
		break;
	case VolDumpEstimate_OP:
		printf("VolDumpEstimate_OP");
		break;
	case VolNewDump_OP:
		printf("VolNewDump_OP");
		break;
	case VolClone_OP:
		printf("VolClone_OP");
		break;
	case VolRestore_OP:
		printf("VolRestore_OP");
		break;
	case VolMerge_OP:
		printf("VolMerge_OP");
		break;
	case VolMakeBackups_OP:
		printf("VolMakeBackups_OP");
		break;
	case VolMarkAsAncient_OP:
		printf("VolMarkAsAncient_OP");
		break;
	case VolDumpMem_OP:
		printf("VolDumpMem_OP");
		break;
	case VolLock_OP:
		printf("VolLock_OP");
		break;
	case VolUnlock_OP:
		printf("VolUnlock_OP");
		break;
	case VolRVMSize_OP:
		printf("VolRVMSize_OP");
		break;
	case VolSetLogParms_OP:
		printf("VolSetLogParms_OP");
		break;
	case VolTiming_OP:
		printf("VolTiming_OP");
		break;
	case PrintStats_OP:
		printf("PrintStats_OP");
		break;
	case TraceRpc_OP:
		printf("TraceRpc_OP");
		break;
	case ShowCallbacks_OP:
		printf("ShowCallbacks_OP");
		break;
	case TruncateRVMLog_OP:
		printf("TruncateRVMLog_OP");
		break;
	case VolGetMaxVolId_OP:
		printf("VolGetMaxVolId_OP");
		break;
	case VolSetMaxVolId_OP:
		printf("VolSetMaxVolId_OP");
		break;
	case VolPeekInt_OP:
		printf("VolPeekInt_OP");
		break;
	case VolPokeInt_OP:
		printf("VolPokeInt_OP");
		break;
	case VolPeekMem_OP:
		printf("VolPeekMem_OP");
		break;
	case VolPokeMem_OP:
		printf("VolPokeMem_OP");
		break;
	case VolSwapmalloc_OP:
		printf("VolSwapmalloc_OP");
		break;
	case NewVolMarkAsAncient_OP:
		printf("NewVolMarkAsAncient_OP");
		break;
	case GetVolumeList_OP:
		printf("GetVolumeList_OP");
		break;
	case VolDumpVRDB_OP:
		printf("VolDumpVRDB_OP");
		break;
	default:
		printf("%d",opcode);
    }
}
