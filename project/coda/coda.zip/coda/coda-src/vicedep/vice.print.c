
#ifdef __cplusplus
extern "C" {
#endif

#include <sys/types.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>


#ifdef __cplusplus
}
#endif

#define _PAD(n)	((((n)-1) | 3) + 1)

int srv_PrintOpcode(int opcode, int subsysid) {
/*    Subsystem : srv */

    printf("srv:");

    switch (opcode) {
	case RPC2_NEWCONNECTION:
		printf("RPC2_NEWCONNECTION");
		break;
	case ViceGetAttr_OP:
		printf("ViceGetAttr_OP");
		break;
	case ViceGetACL_OP:
		printf("ViceGetACL_OP");
		break;
	case ViceFetch_OP:
		printf("ViceFetch_OP");
		break;
	case ViceSetAttr_OP:
		printf("ViceSetAttr_OP");
		break;
	case ViceSetACL_OP:
		printf("ViceSetACL_OP");
		break;
	case ViceStore_OP:
		printf("ViceStore_OP");
		break;
	case ViceGetRootVolume_OP:
		printf("ViceGetRootVolume_OP");
		break;
	case ViceSetRootVolume_OP:
		printf("ViceSetRootVolume_OP");
		break;
	case ViceGetVolumeStatus_OP:
		printf("ViceGetVolumeStatus_OP");
		break;
	case ViceSetVolumeStatus_OP:
		printf("ViceSetVolumeStatus_OP");
		break;
	case ViceDisconnectFS_OP:
		printf("ViceDisconnectFS_OP");
		break;
	case ViceGetTime_OP:
		printf("ViceGetTime_OP");
		break;
	case TokenExpired_OP:
		printf("TokenExpired_OP");
		break;
	case ViceGetOldStatistics_OP:
		printf("ViceGetOldStatistics_OP");
		break;
	case ViceGetStatistics_OP:
		printf("ViceGetStatistics_OP");
		break;
	case ViceGetVolumeInfo_OP:
		printf("ViceGetVolumeInfo_OP");
		break;
	case ViceGetVolumeLocation_OP:
		printf("ViceGetVolumeLocation_OP");
		break;
	case ViceCOP2_OP:
		printf("ViceCOP2_OP");
		break;
	case ViceResolve_OP:
		printf("ViceResolve_OP");
		break;
	case ViceRepair_OP:
		printf("ViceRepair_OP");
		break;
	case ViceSetVV_OP:
		printf("ViceSetVV_OP");
		break;
	case ViceAllocFids_OP:
		printf("ViceAllocFids_OP");
		break;
	case ViceValidateAttrs_OP:
		printf("ViceValidateAttrs_OP");
		break;
	case ViceNewConnectFS_OP:
		printf("ViceNewConnectFS_OP");
		break;
	case ViceGetVolVS_OP:
		printf("ViceGetVolVS_OP");
		break;
	case ViceValidateVols_OP:
		printf("ViceValidateVols_OP");
		break;
	case ViceVRemove_OP:
		printf("ViceVRemove_OP");
		break;
	case ViceVCreate_OP:
		printf("ViceVCreate_OP");
		break;
	case ViceVRename_OP:
		printf("ViceVRename_OP");
		break;
	case ViceVSymLink_OP:
		printf("ViceVSymLink_OP");
		break;
	case ViceVLink_OP:
		printf("ViceVLink_OP");
		break;
	case ViceVMakeDir_OP:
		printf("ViceVMakeDir_OP");
		break;
	case ViceVRemoveDir_OP:
		printf("ViceVRemoveDir_OP");
		break;
	case ViceOpenReintHandle_OP:
		printf("ViceOpenReintHandle_OP");
		break;
	case ViceQueryReintHandle_OP:
		printf("ViceQueryReintHandle_OP");
		break;
	case ViceSendReintFragment_OP:
		printf("ViceSendReintFragment_OP");
		break;
	case ViceCloseReintHandle_OP:
		printf("ViceCloseReintHandle_OP");
		break;
	case ViceReintegrate_OP:
		printf("ViceReintegrate_OP");
		break;
	case ViceGetAttrPlusSHA_OP:
		printf("ViceGetAttrPlusSHA_OP");
		break;
	case ViceValidateAttrsPlusSHA_OP:
		printf("ViceValidateAttrsPlusSHA_OP");
		break;
	default:
		printf("%d",opcode);
    }
}
