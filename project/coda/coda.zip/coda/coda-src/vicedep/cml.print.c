
#ifdef __cplusplus
extern "C" {
#endif

#include <sys/types.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>


#ifdef __cplusplus
}
#endif

#define _PAD(n)	((((n)-1) | 3) + 1)

int cml_PrintOpcode(int opcode, int subsysid) {
/*    Subsystem : cml */

    printf("cml:");

    switch (opcode) {
	case CML_Create_OP:
		printf("CML_Create_OP");
		break;
	case CML_BrokenRemove_OP:
		printf("CML_BrokenRemove_OP");
		break;
	case CML_Rename_OP:
		printf("CML_Rename_OP");
		break;
	case OLDCML_Remove_OP:
		printf("OLDCML_Remove_OP");
		break;
	case OLDCML_Create_OP:
		printf("OLDCML_Create_OP");
		break;
	case OLDCML_Rename_OP:
		printf("OLDCML_Rename_OP");
		break;
	case OLDCML_SymLink_OP:
		printf("OLDCML_SymLink_OP");
		break;
	case OLDCML_Link_OP:
		printf("OLDCML_Link_OP");
		break;
	case OLDCML_MakeDir_OP:
		printf("OLDCML_MakeDir_OP");
		break;
	case OLDCML_RemoveDir_OP:
		printf("OLDCML_RemoveDir_OP");
		break;
	case CML_Store_OP:
		printf("CML_Store_OP");
		break;
	case CML_Truncate_OP:
		printf("CML_Truncate_OP");
		break;
	case CML_Utimes_OP:
		printf("CML_Utimes_OP");
		break;
	case CML_Chmod_OP:
		printf("CML_Chmod_OP");
		break;
	case CML_Chown_OP:
		printf("CML_Chown_OP");
		break;
	case CML_SymLink_OP:
		printf("CML_SymLink_OP");
		break;
	case CML_Link_OP:
		printf("CML_Link_OP");
		break;
	case CML_MakeDir_OP:
		printf("CML_MakeDir_OP");
		break;
	case CML_RemoveDir_OP:
		printf("CML_RemoveDir_OP");
		break;
	case CML_Repair_OP:
		printf("CML_Repair_OP");
		break;
	case CML_Remove_OP:
		printf("CML_Remove_OP");
		break;
	case OLDCML_Repair_OP:
		printf("OLDCML_Repair_OP");
		break;
	case OLDCML_NewStore_OP:
		printf("OLDCML_NewStore_OP");
		break;
	default:
		printf("%d",opcode);
    }
}
