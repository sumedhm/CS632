
#ifdef __cplusplus
extern "C" {
#endif

#include <sys/types.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>


#ifdef __cplusplus
}
#endif

#define _PAD(n)	((((n)-1) | 3) + 1)

int resolution_PrintOpcode(int opcode, int subsysid) {
/*    Subsystem : resolution */

    printf("resolution:");

    switch (opcode) {
	case COP2_OP:
		printf("COP2_OP");
		break;
	case RPC2_NEWCONNECTION:
		printf("RPC2_NEWCONNECTION");
		break;
	case ForceFile_OP:
		printf("ForceFile_OP");
		break;
	case LockAndFetch_OP:
		printf("LockAndFetch_OP");
		break;
	case UnlockVol_OP:
		printf("UnlockVol_OP");
		break;
	case MarkInc_OP:
		printf("MarkInc_OP");
		break;
	case FetchFile_OP:
		printf("FetchFile_OP");
		break;
	case ForceVV_OP:
		printf("ForceVV_OP");
		break;
	case DoForceDirOps_OP:
		printf("DoForceDirOps_OP");
		break;
	case GetForceDirOps_OP:
		printf("GetForceDirOps_OP");
		break;
	case FetchLogs_OP:
		printf("FetchLogs_OP");
		break;
	case ShipLogs_OP:
		printf("ShipLogs_OP");
		break;
	case HandleInc_OP:
		printf("HandleInc_OP");
		break;
	case InstallVV_OP:
		printf("InstallVV_OP");
		break;
	case FetchDirContents_OP:
		printf("FetchDirContents_OP");
		break;
	case ClearIncon_OP:
		printf("ClearIncon_OP");
		break;
	case NewShipLogs_OP:
		printf("NewShipLogs_OP");
		break;
	default:
		printf("%d",opcode);
    }
}
