
#ifdef __cplusplus
extern "C" {
#endif

#include <sys/types.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>


#ifdef __cplusplus
}
#endif

#define _PAD(n)	((((n)-1) | 3) + 1)

int cb_PrintOpcode(int opcode, int subsysid) {
/*    Subsystem : cb */

    printf("cb:");

    switch (opcode) {
	case RPC2_NEWCONNECTION:
		printf("RPC2_NEWCONNECTION");
		break;
	case CallBack_OP:
		printf("CallBack_OP");
		break;
	case CallBackFetch_OP:
		printf("CallBackFetch_OP");
		break;
	default:
		printf("%d",opcode);
    }
}
