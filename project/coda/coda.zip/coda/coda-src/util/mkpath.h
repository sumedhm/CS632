/* mkpath.h: prototype.
*/

#ifdef __cplusplus
extern "C" {
#endif

int mkpath (const char *name, mode_t mode);

#ifdef __cplusplus
}
#endif
