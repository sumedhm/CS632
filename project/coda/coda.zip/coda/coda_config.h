#ifndef _CODA_CONF_H_
#define _CODA_CONF_H_ 1

/* Define to the location of the configuration files */
#define SYSCONFDIR "/etc/coda"

/* Define the cpu type for @cpu expansion */
#define CPUTYPE "x86_64"

/* Define the system type for @sys expansion */
#define SYSTYPE "x86_64_linux"

#endif /* _CODA_CONF_H_ */
