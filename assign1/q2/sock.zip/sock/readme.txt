
Different threads for different users.

/*Partial matches allowed*/
search can be using name or author - "search name search_string"
search can be using book id

show_all - search name (empty)

add new book_name
add copy book_id

book book_id

issue book_id

return book_id copy_id

renew book_id copy_id

