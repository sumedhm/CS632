#!bin/bash

clear
java -Djava.security.policy=server.policy RoomBookingClient
