package server;
import java.rmi.*;

public interface RoomBookingInterface extends Remote{
	public String sayHello(String msg) throws RemoteException;
}
